from django.apps import AppConfig


class RoleplayGameAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "roleplay_game_app"
